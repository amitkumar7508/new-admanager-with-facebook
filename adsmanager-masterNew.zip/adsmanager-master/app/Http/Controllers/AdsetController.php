<?php
namespace App\Http\Controllers;

define('APP_ID', '242735782770477'); 
define('APP_SECRET', '0db0e024c7bc2a4efe5ea233ff3579b7'); 
define('ACCOUNT_ID', 'act_1457210341254989'); 
define('REDIRECT_URL', 'http://laravel.dev/facebooklogin'); 

define('facebooksdk', __DIR__.'\facebook\php-sdk-v4'); 
include facebooksdk.'/vendor/autoload.php';

define('SDK_DIR', __DIR__.'\facebook'); 
$loader = include SDK_DIR.'/vendor/autoload.php';
date_default_timezone_set('America/Los_Angeles');
use FacebookAds\Api;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\Fields\AdAccountFields;
use FacebookAds\Object\Campaign;
//use FacebookAds\Object\AdCampaign;
use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Object\Targeting;
use FacebookAds\Object\Fields\TargetingFields;
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Values\AdSetBillingEventValues;
use FacebookAds\Object\Values\AdSetOptimizationGoalValues;



use Illuminate\Http\Request;

class AdsetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
			$All_adsets=array();
			$access_token = session('accesstoken');	
			Api::init(APP_ID, APP_SECRET, $access_token);
			$api = Api::instance();
			$account = (new AdAccount(ACCOUNT_ID))->read(array(
					  AdAccountFields::ID,
					  AdAccountFields::NAME,
					  AdAccountFields::ACCOUNT_STATUS,
			));
			
		
			$adcampaign_id=trim($_POST['campaign_id']);
			$adcampaign = new Campaign($adcampaign_id);
			$adsets = $adcampaign->getAdSets(array(
			  AdSetFields::ID,
			  AdSetFields::NAME
			));
			foreach ($adsets as $adset) {
				$All_adsets[]=$adset->name;
			}
			return View('show_adsets', ['All_adsets' => $All_adsets]); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {	
		$campaign_id=$_POST['campaign_id'];
		return View('adsetform',['CAMPAIGN_ID' => $campaign_id]);	
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {		
		$access_token = session('accesstoken');	
		Api::init(APP_ID, APP_SECRET, $access_token);
		$api = Api::instance(); 
		$account = (new AdAccount(ACCOUNT_ID))->read(array(
					  AdAccountFields::ID,
					  AdAccountFields::NAME,
					  AdAccountFields::ACCOUNT_STATUS,
					));
        $targeting = new Targeting();
		$targeting->setData(array(
			TargetingFields::GEO_LOCATIONS => array(
				'countries' => array('JP'),
				'regions' => array(array('key' => '3886')),
				'cities' => array(
					array(
						'key' => '2420605',
						'radius' => 10,
						'distance_unit' => 'mile',
					),
				),
			),
		));
		try{
			$adset = new AdSet(null,ACCOUNT_ID);
			
				
			$adset->setData(array(
				AdSetFields::NAME => trim($_POST['Adset_Name']),
				AdSetFields::CAMPAIGN_ID => trim($_POST['campaign_id']),
				AdSetFields::DAILY_BUDGET => '150',
				AdSetFields::TARGETING => $targeting,
				AdSetFields::OPTIMIZATION_GOAL => AdSetOptimizationGoalValues::REACH,
				AdSetFields::BILLING_EVENT => AdSetBillingEventValues::IMPRESSIONS,
				AdSetFields::BID_AMOUNT => 100,
				AdSetFields::START_TIME =>
					(new \DateTime("+1 week"))->format(\DateTime::ISO8601),
				AdSetFields::END_TIME =>
					(new \DateTime("+2 week"))->format(\DateTime::ISO8601),
			));

			$adset->validate()->create(array(
				AdSet::STATUS_PARAM_NAME => AdSet::STATUS_ACTIVE,
			));

			return 'AdSet  ID: '. $adset->id . "\n"; 
		  }catch (Exception $e) {  
				return 'Error message: ' .$e->getMessage() ."\n" . "<br/>";
				return 'Error Code: ' .$e->getCode() ."<br/>";
			}
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
