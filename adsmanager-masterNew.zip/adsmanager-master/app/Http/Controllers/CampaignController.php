<?php
namespace App\Http\Controllers;

define('APP_ID', '242735782770477'); 
define('APP_SECRET', '0db0e024c7bc2a4efe5ea233ff3579b7'); 
define('ACCOUNT_ID', 'act_1457210341254989'); 
define('REDIRECT_URL', 'http://laravel.dev/facebooklogin'); 


define('facebooksdk', __DIR__.'\facebook\php-sdk-v4'); 
include facebooksdk.'/vendor/autoload.php';

define('SDK_DIR', __DIR__.'\facebook'); 
$loader = include SDK_DIR.'/vendor/autoload.php';
date_default_timezone_set('America/Los_Angeles');

use Illuminate\Http\Request;
use Validator;
use Session;
use Facebook\Facebook;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;
use FacebookAds\Api;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\Fields\AdAccountFields;
use FacebookAds\Object\Campaign;
use FacebookAds\Object\Fields\CampaignFields;
		

class CampaignController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){	
				$fb = new Facebook(['app_id' => APP_ID,'app_secret' => APP_SECRET]);
				$helper = $fb->getRedirectLoginHelper();
				
				/* if(!empty(session('accesstoken'))){
					session::forget('accesstoken');
				}
				 */
				
				if(isset($_GET['code'])){
					  try {
						$accesstoken	= (string) $helper->getAccessToken();
						session::put('accesstoken',$accesstoken);
						return redirect('campaigns');
					  } catch(FacebookResponseException $e) {
						// When Graph returns an error
						echo 'Graph returned an error: ' . $e->getMessage();
						exit;
					  } catch(FacebookSDKException $e) {
						// When validation fails or other local issues
						echo 'Facebook SDK returned an error: ' . $e->getMessage();
						exit;
					  }
				}else{
					$permissions = ['ads_management'];	
					$loginUrl = $helper->getLoginUrl(REDIRECT_URL,$permissions);
					return View('facebooklogin', ['loginUrl' => $loginUrl]);
				}
    }
	
	
	
	public function listcampaign(){
		
			$All_campaign=array();
			$access_token = session('accesstoken');
			Api::init(APP_ID,APP_SECRET ,$access_token);
			$api = Api::instance(); 
			
			 $account = (new AdAccount(ACCOUNT_ID))->read(array(
					  AdAccountFields::ID,
					  AdAccountFields::NAME,
					  AdAccountFields::ACCOUNT_STATUS,
					));
					
			if($account->{AdAccountFields::ACCOUNT_STATUS} !== 1) {
				$message='This account is not active';
				return $message;
			} 
			
			$cursor = $account->getCampaigns( 
												array(
													CampaignFields::ID,
													CampaignFields::NAME,
													CampaignFields::OBJECTIVE,
													CampaignFields::CONFIGURED_STATUS,
													CampaignFields::CREATED_TIME,
												) 
											);
												
												
			foreach ($cursor as $campaign) {
			
				$campaign_array=array();
				$campaign_array['campaign_id']=   $campaign->{CampaignFields::ID}.PHP_EOL;
				$campaign_array['campaign_name']=   $campaign->{CampaignFields::NAME}.PHP_EOL;
				$campaign_array['campaign_objective']=   $campaign->{CampaignFields::OBJECTIVE}.PHP_EOL;
				$campaign_array['campaign_status']=   $campaign->{CampaignFields::CONFIGURED_STATUS}.PHP_EOL;
				$d=strtotime($campaign->{CampaignFields::CREATED_TIME}.PHP_EOL);
				$campaign_array['created_time']=   date('d/m/Y h:i:s',$d);
				$All_campaign[]=$campaign_array;
				
			}
		
		return View('show_campaigns', ['All_campaign' => $All_campaign]); 
		 
	}
	
	
	public function get_campaignform(){
		return View('campaignform');	
	}
	
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){	
	

    }
	

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
		$validator = Validator::make($request->all(), [
            'Campaign_Name' => 'required',
            'Objective_Name' => 'required',
        ]);
		if($validator->fails()){
            return redirect('/campaigns/create/')
            ->withInput()
            ->withErrors($validator);
        }
		
		
		
      	$access_token = session('accesstoken');
		Api::init(APP_ID,APP_SECRET ,$access_token);
		try{
				$campaign  = new Campaign(null, ACCOUNT_ID);
				$campaign->setData(array(
					CampaignFields::NAME => $request->input('Campaign_Name'),
					CampaignFields::OBJECTIVE => $request->input('Objective_Name'),
				));

				$campaign->validate()->create(array(
					Campaign::STATUS_PARAM_NAME => Campaign::STATUS_PAUSED,
				));
				return redirect('/campaigns/create');
		}catch (Exception $e) {
				return 'Error message: ' .$e->getMessage() ."\n" . "<br/>";
				return 'Error Code: ' .$e->getCode() ."<br/>";
		}  	
		
    }
	
	public function delete(Request $request){
			$campaign_id=trim($_POST['campaign_id']);
			var_dump(	$campaign_id);
			$camp_id=(int)$campaign_id;
				
			$campaign = new Campaign(6068290729829);
			
			$campaign->delete();
		
	}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
