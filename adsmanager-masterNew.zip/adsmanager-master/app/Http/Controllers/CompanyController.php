<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Company;
use Session;

class CompanyController extends Controller
{
    
	
	public function index() {

		$companies = Company::orderBy('id', 'desc')->paginate(10);


		return View('show_companies', ['companies' => $companies]);
	}
	
	public function create() {

		return View('create_company');
		
	}
	
	public function store(Request $request) {

		$validator = Validator::make($request->all(), [
            'name' => 'required',
            'logo' => 'required',
        ]);

        if($validator->fails()){
            return redirect('companies/create/')
            ->withInput()
            ->withErrors($validator);
        }

        Company::firstOrCreate(['name' => $request->input('name'), 'logo' => $request->input('logo')]);

        Session::flash('success', 'Lyckades!');
  
		return redirect('/companies/create');

	}
}
